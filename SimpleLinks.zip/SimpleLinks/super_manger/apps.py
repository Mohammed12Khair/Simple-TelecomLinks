from django.apps import AppConfig


class SuperMangerConfig(AppConfig):
    name = 'super_manger'
